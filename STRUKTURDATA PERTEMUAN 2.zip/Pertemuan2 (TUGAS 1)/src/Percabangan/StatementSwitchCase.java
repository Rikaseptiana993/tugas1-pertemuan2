/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Percabangan;

/**
 *
 * @author HP
 */
public class StatementSwitchCase {
      public static void main(String[] args) 
    {

        int minggu = 6;

        switch (minggu) 
        {
            case 1:
                System.out.println("Bulan ini minggu 1");
                break;
            case 2:
                System.out.println("Bulan ini minggu 2");
                break;
            case 3:
                System.out.println("Bulan ini minggu 3");
                break;
            case 4:
                System.out.println("Bulan ini minggu 4");
                break;
            default:
                System.out.println("Tidak ada pilihan");
        }
    }
    
}
