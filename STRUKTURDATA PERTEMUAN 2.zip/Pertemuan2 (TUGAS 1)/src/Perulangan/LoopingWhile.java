/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Perulangan;

/**
 *
 * @author HP
 */
public class LoopingWhile {
    
    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) 
    {
        int i = 1;
        while(i <= 7) {
            System.out.println("Angka = " + i);
            i++;
        }
    }
}