/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TipeData;

/**
 *
 * @author HP
 */
public class Biodata {
    public static void main(String[] args) 
    {
        String nim = "2355201026";
        String nama = "RIKA SEPTIANA";
        Double BB = 60.2;
        int umur = 20;
        char goldar = 'O';
        boolean perempuan = true ;
        
        System.out.println("----------------BIODATA------------------");
        System.out.println("NIM              : " + nim);
        System.out.println("NAMA             : " + nama);
        System.out.println("BERAT BADAN      : " + BB + " Kg");
        System.out.println("UMUR             : " + umur + " tahun");
        System.out.println("GOLONGAN DARAH   : " + goldar);
        System.out.println("GENDER laki laki : " + perempuan);
    }
    
}
